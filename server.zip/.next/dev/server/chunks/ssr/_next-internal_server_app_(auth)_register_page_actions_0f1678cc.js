module.exports = [
"[project]/.next-internal/server/app/(auth)/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_register_page_actions_0f1678cc.js.map