module.exports = [
"[project]/.next-internal/server/app/(public)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28public%29_page_actions_cf7ff801.js.map