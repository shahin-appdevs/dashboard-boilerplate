module.exports = [
"[project]/src/app/(admin)/_components/homepage/Layouts/LayoutSidebar.jsx [app-ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_0f8499a9._.js",
  "server/chunks/ssr/src_app_(admin)__components_homepage_Layouts_LayoutSidebar_jsx_0e5b0e0c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/(admin)/_components/homepage/Layouts/LayoutSidebar.jsx [app-ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
];